"""
CLI OpenHackintosh — terminal-first.

Uso:
    openhackintosh                 -> menu interattivo
    openhackintosh detect [--json]
    openhackintosh info [--json]
    openhackintosh diagnose [--json]
    openhackintosh compatibility [--json]
    openhackintosh generate [--json] [--dev]
    openhackintosh validate ./EFI [--json]
    openhackintosh doctor [--json]
    openhackintosh database list|show [id] [--json]
    openhackintosh ask "<domanda>" [--json]

Ogni comando principale supporta --json per output strutturato.
"""

from __future__ import annotations

import argparse
import sys
from typing import List, Optional

from .output import Out
from .interactive import run_menu

from .commands import (
    run_detect,
    run_info,
    run_diagnose,
    run_compatibility,
    run_generate,
    run_validate,
    run_doctor,
    run_database,
    run_bios,
    run_sources,
)

from version import VERSION_LABEL as VERSION  # unica fonte: src/version.py


def build_parser() -> argparse.ArgumentParser:
    common = argparse.ArgumentParser(add_help=False)
    common.add_argument("--json", action="store_true", help="Output JSON strutturato")
    common.add_argument("--dev", action="store_true", help="Modalita' sviluppo: verbose/debug")
    common.add_argument("--force", action="store_true", help="Procedi anche se mancano evidenze")

    parser = argparse.ArgumentParser(
        prog="openhackintosh",
        description="Hardware & EFI Assistant per Hackintosh (OpenCore). CLI-first.",
    )
    parser.add_argument("--version", action="version", version=f"OpenHackintosh {VERSION}")

    sub = parser.add_subparsers(dest="command")

    p_detect = sub.add_parser("detect", parents=[common], help="Rileva l'hardware reale")
    p_detect.set_defaults(func=run_detect)

    p_info = sub.add_parser("info", parents=[common], help="Mostra informazioni su sistema")
    p_info.set_defaults(func=run_info)

    p_diag = sub.add_parser("diagnose", parents=[common], help="Diagnosi completa")
    p_diag.set_defaults(func=run_diagnose)

    p_comp = sub.add_parser("compatibility", parents=[common], help="Controlla compatibilita'")
    p_comp.set_defaults(func=run_compatibility)

    p_gen = sub.add_parser("generate", parents=[common], help="Genera EFI hardware-aware")
    p_gen.add_argument("--profile", help="ID profilo (es. fujitsu_q556_2)")
    p_gen.add_argument("--macos", default="Ventura 13.x", help="Versione macOS")
    p_gen.add_argument("--smbios", default="iMac18,1", help="SMBIOS model")
    p_gen.add_argument("--audio-layout", type=int, default=11)
    p_gen.add_argument("--wifi", action="store_true")
    p_gen.add_argument("--bluetooth", action="store_true")
    p_gen.add_argument("--output", default="output/EFI", help="Directory output")
    p_gen.add_argument("--no-zip", action="store_true", help="Non creare ZIP")
    p_gen.add_argument("--include-nvme", action="store_true", help="Includi kext opzionale NVMeFix")
    p_gen.add_argument("--include-restrict-events", action="store_true", help="Includi kext opzionale RestrictEvents")
    p_gen.add_argument("--include-optional-drivers", action="store_true", help="Includi driver opzionali del profilo")
    p_gen.add_argument("--usb-map", action="store_true",
                       help="Genera la mappa USB automatica (inject-kext USBMap, engine manifest)")
    p_gen.add_argument("--engine", choices=["legacy", "manifest"], default="manifest",
                       help="manifest: sources engine v1 (default dalla 2.0.2, database delle fonti); legacy: builder storico")
    p_gen.add_argument("--manifest", default=None, help="Percorso sources manifest custom (implica --engine manifest)")
    p_gen.set_defaults(func=run_generate)

    p_val = sub.add_parser("validate", parents=[common], help="Valida una EFI")
    p_val.add_argument("efi_path", help="Percorso cartella EFI")
    p_val.set_defaults(func=run_validate)

    p_doc = sub.add_parser("doctor", parents=[common], help="Diagnostica ambiente/tool")
    p_doc.set_defaults(func=run_doctor)

    p_bios = sub.add_parser("bios", parents=[common], help="Guida BIOS specifica per profilo")
    p_bios.add_argument("--profile", default=None, help="ID profilo (es. fujitsu_q556_2)")
    p_bios.set_defaults(func=run_bios)

    p_db = sub.add_parser("database", parents=[common], help="Gestisci/consulta profili")
    db_sub = p_db.add_subparsers(dest="db_command")
    p_db_list = db_sub.add_parser("list", parents=[common], help="Elenca profili")
    p_db_list.set_defaults(func=run_database, db_command="list")
    p_show = db_sub.add_parser("show", parents=[common], help="Mostra profilo")
    p_show.add_argument("id")
    p_show.set_defaults(func=run_database, db_command="show")

    p_src = sub.add_parser("sources", parents=[common], help="Database delle fonti (sources engine 2.0.2)")
    src_sub = p_src.add_subparsers(dest="sources_command")
    p_src_list = src_sub.add_parser("list", parents=[common], help="Elenca i profili con sources manifest")
    p_src_list.set_defaults(func=run_sources, sources_command="list")
    p_src_show = src_sub.add_parser("show", parents=[common], help="Mostra file e fonti del manifest")
    p_src_show.add_argument("--profile", required=True, help="ID profilo (es. fujitsu_q556_2)")
    p_src_show.set_defaults(func=run_sources, sources_command="show")
    p_src_check = src_sub.add_parser("check", parents=[common], help="Verifica coerenza manifest <-> profilo")
    p_src_check.add_argument("--profile", required=True, help="ID profilo (es. fujitsu_q556_2)")
    p_src_check.set_defaults(func=run_sources, sources_command="check")

    p_ask = sub.add_parser("ask", parents=[common], help="Fai una domanda all'assistant (dati strutturati)")
    p_ask.add_argument("question", nargs="*")
    p_ask.set_defaults(func=run_ask)

    return parser


def run_ask(args, out: Out) -> dict:
    from hardware import detect_and_capture
    from ai import Assistant

    snapshot = detect_and_capture()
    result = snapshot.result
    question = " ".join(args.question) or "Riassunto"
    assistant = Assistant()
    answer = assistant.answer(question, result)
    payload = {
        "question": question,
        "answer": answer,
        "result": result.to_dict(),
        "match": snapshot.match.to_dict() if snapshot.match else {"match_type": "NO_MATCH"},
    }
    out.data(payload, "AI & EFI Assistant")
    return payload


#: Voci del menu interattivo. Definite a livello di modulo cosi' il selettore
#: e i test possono verificare che OGNI opzione (comprese le multi-cifra) sia
#: raggiungibile e mappata sull'azione corretta.
MENU_ITEMS: List[dict] = [
    {"label": "Analyze this computer", "action": "diagnose"},
    {"label": "Generate EFI", "action": "generate"},
    {"label": "Validate EFI", "action": "validate"},
    {"label": "Check compatibility", "action": "compatibility"},
    {"label": "View hardware", "action": "detect"},
    {"label": "View database", "action": "database"},
    {"label": "BIOS guide", "action": "bios"},
    {"label": "Doctor", "action": "doctor"},
    {"label": "Ask the assistant", "action": "ask"},
    {"label": "Exit", "action": "exit"},
]

#: Mappatura azione del menu -> argomenti del sottocomando CLI corrispondente.
MENU_COMMANDS = {
    "diagnose": ["diagnose"],
    "generate": ["generate", "--output", "output/EFI"],
    "validate": ["validate", "output/EFI"],
    "compatibility": ["compatibility"],
    "detect": ["detect"],
    "database": ["database", "list"],
    "bios": ["bios", "--profile", "fujitsu_q556_2"],
    "doctor": ["doctor"],
    "ask": ["ask"],
}


def interactive_main(out: Out) -> None:
    items: List[dict] = [dict(item) for item in MENU_ITEMS]
    choice = run_menu(items)
    if choice is None or choice.get("action") == "exit":
        return

    # Esegue la stessa logica dei sottocomandi
    parser = build_parser()
    argv = list(MENU_COMMANDS.get(choice["action"], ["doctor"]))
    if out.json_output:
        argv.append("--json")
    if out.dev:
        argv.append("--dev")
    args = parser.parse_args(argv)
    run_command(args, parser, Out(json_output=out.json_output, dev=out.dev))


def run_command(args, parser, out: Out) -> int:
    if not getattr(args, "func", None):
        parser.print_help()
        return 0
    try:
        result = args.func(args, out)
        if isinstance(result, dict):
            if result.get("ok") is False or result.get("success") is False:
                return 1
        return 0
    except SystemExit as e:
        return int(e.code or 0)
    except Exception as exc:
        if out.json_output:
            out.data({"ok": False, "error": str(exc)})
        else:
            print(f"Errore: {exc}")
        return 1


def main(argv: Optional[List[str]] = None) -> int:
    argv = sys.argv[1:] if argv is None else argv
    parser = build_parser()

    # Nessun comando -> interfaccia interattiva
    if not argv:
        out = Out(json_output=False, dev=False)
        interactive_main(out)
        return 0

    # Se --json/--dev compare prima del sottocomando, lo spostiamo
    pre_flags = []
    rest = []
    for arg in argv:
        if arg in ("--json", "--dev", "--force") and not rest:
            pre_flags.append(arg)
        else:
            rest.append(arg)
    if pre_flags:
        argv = rest + pre_flags

    args = parser.parse_args(argv)
    out = Out(json_output=getattr(args, "json", False), dev=getattr(args, "dev", False))
    return run_command(args, parser, out)


if __name__ == "__main__":
    sys.exit(main())
