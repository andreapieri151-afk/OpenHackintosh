# Changelog - Tutte le bestemmie in ordine cronologico

## 2.0.3 Stable - 2026-10-09 — HOTFIX WINDOWS (menu loop + HfsPlus + UX)

Release di correzione: tre bug segnalati dal test su macchina reale Windows,
nessuna nuova funzionalità.

### Fix
- **Menu: il tool usciva dopo ogni comando** — ora `interactive_main` gira
  in loop: esegue il comando scelto, attende un tasto e torna al menu
  principale, finché non si sceglie "Exit" (o EOF/Ctrl+C). Ctrl+C durante un
  comando non uccide più il tool: riporta al menu. Su stdin non-TTY
  (pipe/CI) il comportamento resta identico (`echo 8 | ./openhackintosh`).
- **EFI generation falliva su `hfsplus`** — OpenCorePkg 1.0.8 non include
  più `X64/EFI/OC/Drivers/HfsPlus.efi` (il driver proprietario Apple non è
  redistribuibile nel pacchetto): il manifest ora dichiara una lista di path
  candidati (`HfsPlus.efi` → `OpenHfsPlus.efi` → `HfsPlusLegacy.efi`) e il
  resolver usa il primo che esiste nell'archivio. Il file viene comunque
  materializzato in `OC/Drivers/HfsPlus.efi`; il campo `resolved` del ledger
  registra quale membro dell'archivio è stato usato davvero. Se nessun
  candidato esiste, l'errore elenca i driver `.efi` presenti nell'archivio
  per diagnosi immediata.
- **UX menu** — in modalità raw i tasti non hanno eco: la selezione numerica
  "agiva senza mostrare nulla". Ora ogni selezione (numero o frecce+Invio)
  mostra la riga di conferma `✔ N. Label` prima di eseguire il comando.

### Tecnico
- `sources.schema`: `path_in_archive` accetta stringa o lista di candidati.
- `sources.resolver`: ricerca multi-candidato + `_archive_hint` diagnostico +
  campo `resolved` in `MaterializedComponent`.
- `cli.main`: loop del menu + `_pause_before_menu()` (no-op fuori da TTY).
- `cli.selector`: `_draw_choice_feedback()` dopo ogni SELECTED.
- Test: `tests/test_fixes_203.py` (14 casi: fallback HfsPlus, diagnosi
  archivio, loop del menu, pausa, Ctrl+C, feedback visibile).
- Versione: `2.0.3 Stable`; release `releases/OpenHackintosh-2.0.3.zip`.

## 2.0.2 Stable - 2026-10-09 — SOURCES ENGINE DI DEFAULT + USB MAPPING

La 2.0.2 cambia il cuore del tool: i file della EFI e le fonti da cui
scaricarli non sono più hardcoded nel builder, ma vivono in un database
dichiarativo (JSON) che un algoritmo di generazione consuma passo passo:

    Sources Manifest -> FETCH -> VERIFY -> ASSEMBLE -> AUDIT -> ZIP

Dalla 2.0.2 Stable il sources engine e' il **motore di default** di
`generate` (`--engine legacy` per il builder storico). I profili senza
sources manifest (es. fujitsu_q957) ripiegano su legacy automaticamente.

### Aggiunto — sources engine v1 (`src/sources/`)

- **Sources manifest** (`src/database/sources/<profilo>/sources.json`): per
  ogni file della EFI dichiara kind (`efi_binary`/`kext`/`aml`/`generated`),
  target nella cartella EFI, fonte (`github_release`/`github_raw`/`url`/
  `generated`), `min_size`, pin `sha256` opzionale, required/optional_group e
  `provenance` (`default` = fonte canonica ufficiale; `verified` = confermata
  dal maintainer). Schema rigido: campi sconosciuti, target duplicati, path
  traversal e incoerenze kind/source sono errori di validazione.
- **Manifest del Fujitsu Esprimo Q556/2** (`fujitsu_q556_2`): 19 componenti —
  OpenCore/BOOTx64/HfsPlus/OpenRuntime da `acidanthera/OpenCorePkg`, kext da
  `acidanthera/*` e `Mieze/RTL8111_driver_for_OS_X`, SSDT da Dortania,
  config.plist e README generati dal motore. Tutte le fonti sono `default`:
  da confermare/pinnare (passo successivo del rilascio 2.0.2).
- **Loader + consistency check**: il manifest deve coprire TUTTI i kext,
  driver e SSDT required del profilo hardware, altrimenti la generazione
  si rifiuta di partire (prima ancora di toccare la rete).
- **Fetcher iniettabile**: `GitHubFetcher` (produzione: Releases API, cache,
  invalidazione zip corrotti, fallback SSL) e `InMemoryFetcher` (test
  offline). La rete entra in un solo punto del motore.
- **Resolver**: estrazione esatta del file/bundle dichiarato dall'archivio +
  validazione binaria reale (PE/COFF, Mach-O/kext bundle, firma AML) +
  min_size + sha256 pin. Esiti per componente: OK / FAILED / SKIPPED.
- **Pipeline**: assembly dell'albero EFI, generazione config.plist/SMBIOS/
  README con **provenance ledger** (fonte + sha256 per ogni componente),
  final audit riusato dalla 2.0.1, ZIP `EFI_<PROFILO>.zip`. Se un componente
  required fallisce: FAILED, niente ZIP, niente EFI parziale.
- **CLI**:
  - `openhackintosh sources list|show|check --profile <id>` — consulta e
    valida il database delle fonti;
  - `openhackintosh generate --engine manifest` (e `--manifest <path>`) —
    genera la EFI col sources engine. Il motore di default resta `legacy`
    finché le fonti non saranno confermate/pinnate.
- **Test**: 56 nuovi test (319 totali, tutti verdi) — schema/validazione,
  coerenza manifest↔profilo, pipeline end-to-end offline con binari
  sintetici validi, tutti i failure mode (archivio mancante, kext 0-byte,
  magic sbagliato, placeholder AML, min_size, sha256 mismatch, zip corrotto),
  opzionali che non bloccano, GitHubFetcher senza rete (monkeypatch).

### Aggiunto — hardening fonti (solo RELEASE, mai DEBUG, mai file finti)

- **Divieto DEBUG a due livelli**: lo schema del manifest rifiuta pattern
  asset contenenti "DEBUG"; il fetcher rifiuta comunque un asset DEBUG anche
  se selezionato (doppia barriera).
- **Versioni pinnate** nel manifest del Q556/2, verificate via GitHub API il
  2026-10-09: OpenCorePkg 1.0.8, Lilu 1.7.2, VirtualSMC 1.3.8,
  WhateverGreen 1.7.1, AppleALC 1.9.8, NVMeFix 1.1.3, RestrictEvents 1.1.6,
  RealtekRTL8111 v3.0.0 (Mieze — verificato che in Acidanthera NON esiste),
  itlwm v2.3.0, IntelBluetoothFirmware v2.4.0. Asset sempre `*-RELEASE.zip`.
- **Template `{macos}` nei pattern asset**: AirportItlwm pubblica un binario
  diverso per ogni macOS; il motore risolve il pattern sul macOS target
  (Ventura -> `AirportItlwm_v2.3.0_stable_Ventura.kext.zip`). Se il macOS
  non ha una variante dichiarata (es. Sequoia con itlwm v2.3.0) il
  componente fallisce con errore esplicito: mai un kext per il macOS
  sbagliato.
- `provenance` aggiornato: componenti Acidanthera/OpenCorePkg/Dortania/Mieze
  -> `verified`; OpenIntelWireless (wifi/bluetooth opzionali) resta
  `default` in attesa di conferma.

### Aggiunto — USB mapping automatico (`src/usb_mapping/`)

- **Detection dei controller XHCI** via sysfs (Linux): classe PCI 0x0c0330,
  PCI ID, slot in formato `pcidebug` e **conteggio reale dei porti** dal
  root hub (oggetti `usbN-portM`). Radice sysfs iniettabile -> testabile su
  albero finto, nessuna dipendenza dall'hardware reale. Su Windows/macOS la
  topologia non e' rilevabile: la mappa NON viene generata (mai inventata).
- **Generazione inject-kext USBMap** nel formato canonico
  (personalita' `AppleUSBHostMergeProperties`, `port-count`, dizionario
  `ports` con `UsbConnector`/`port`), con metadati OpenHackintosh che
  dichiarano lo stato DRAFT: i tipi connettore vanno verificati dopo
  l'installazione.
- **Validazione inject-kext** (`validate_inject_kext`): un bundle solo
  Info.plist (come i veri USBMap.kext) e' legittimo se ha IOKitPersonalities
  non vuote e bundle identifier; il validator dell'EFI ora lo accetta. Un
  bundle vuoto/placeholder resta INVALID.
- **Integrazione nel sources engine**: componente `usb_map` nel manifest del
  Q556/2 (opzionale, gruppo `usb_mapping`), generato PRIMA di config.plist
  cosi' finisce in Kernel/Add e nello ZIP. Se nessun controller e'
  rilevabile il componente viene scartato e la build resta VALID.
- **CLI**: `generate --usb-map` (engine manifest).

### Rimosso

- **Le 5 EFI "sample" in `releases/`** (`EFI-Q5562-*.zip`): contenevano
  binari finti/vuoti (file da 0 byte, "binari" da 4KB). Sono esattamente il
  problema che OpenHackintosh e' nato per eliminare. Le release del tool
  (`OpenHackintosh-*.zip`) restano.

### Corretto

- Import circolare latente `database -> matcher -> hardware -> snapshot ->
  database`: ora `matcher` importa da `hardware` in modo lazy. Il bug era
  invisibile finché si importava `hardware` prima di `database`; il sources
  engine lo avrebbe attivato.

### Cambiato

- **Sources engine come motore di default** di `generate`: il builder legacy
  resta disponibile con `--engine legacy` e come fallback automatico per i
  profili senza manifest.
- Versione: `2.0.2 Stable`; release `releases/OpenHackintosh-2.0.2.zip`.

### Roadmap post-2.0.2

- [ ] Pin sha256 dei binari nel manifest (richiede accesso al CDN release GitHub)
- [ ] Sources manifest per altri profili (Q957, Lenovo Tiny, HP Mini, Dell Micro...)
- [ ] (Valutazione) Layer AI opzionale con chiave API esterna (es. Gemini via AI Studio): spiegazioni + analisi supporto macchina. Mai senza chiave, mai decisionale sulla compatibilita'.

## 2.0.1 Stable - 2026-09-19 — WINDOWS + LINUX, FINE DELLA BETA

La **2.0.1 diventa Stable**: il tool ora gira nativamente su **Windows, Linux
e macOS**, con il rilevamento hardware completo anche su Windows. Stessa
filosofia: niente file finti, niente dati inventati.

### Aggiunto — supporto Windows

- `src/hardware/windows.py`: provider di detection via **PowerShell CIM**
  (`Get-CimInstance`, mai il deprecato `wmic`): DMI/scheda madre/BIOS, CPU,
  dispositivi PnP PCI/USB con VEN/DEV, GPU, audio, Ethernet, Wi-Fi, Bluetooth,
  controller storage e dischi, interfacce di rete, UEFI/Legacy
  (PEFirmwareType). Una sola invocazione batched con output JSON; parsing puro
  e testabile su qualsiasi OS. ACPI tables restano onestamente
  `NOT_AVAILABLE_ON_PLATFORM` su Windows.
- `src/cli/selector.py` — `WindowsKeyReader` (`msvcrt`): frecce, Home/End,
  PgUp/PgDn, Canc, ESC, Ctrl+C e numeri multi-cifra funzionano anche nella
  console Windows; `make_key_reader()` sceglie il lettore giusto in automatico.
- `OpenHackintosh.bat`: launcher Windows (venv automatico, dipendenze,
  `chcp 65001`, esecuzione con un doppio click).
- `src/utils/platforms.py`: `current_platform()` e cache cross-platform
  (`%LOCALAPPDATA%\OpenHackintosh\Cache` su Windows; `~/.cache` su Unix).
- `src/utils/console.py`: bootstrap console — UTF-8 con `errors="replace"`
  (mai più `UnicodeEncodeError` su cp1252) e attivazione VT mode ANSI su
  Windows 10+; logica colori unificata per tutta la CLI.
- Ci GitHub Actions: suite pytest su matrix Windows/Linux/macOS.
- `src/version.py`: unica fonte di verità per il numero di versione.

### Corretto

- Cache download su Windows: prima finiva in `./.cache` nella cartella
  corrente (`HOME` non esiste su Windows) — ora in `%LOCALAPPDATA%`.
- `README`/`README_EFI.txt` generati con encoding esplicito UTF-8
  (crash su Windows con caratteri non-cp1252).
- Nomi dei file generati guidati dal profilo: `EFI_<PROFILO>.zip` e
  `README_EFI.txt` — prima un EFI per Q957 usciva come `EFI_Q5562.zip`.
- `doctor`: controllo scrittura sulla temp dir reale della piattaforma
  (non più `/tmp` fisso).

### Invariato

- Struttura CLI (9 comandi + `ask`), database profili, matcher, compatibilità
  deterministica, EFI hardening/audit. Test: da 177 a 263.

## 2.0.1 Beta 1 — HOTFIX SELETTORE CLI - 2026-09-01

> Stessa versione **2.0.1 Beta 1**, ricostruita con il selettore corretto.
> Non è una 2.0.2. Build: `releases/OpenHackintosh-2.0.1-Beta-1-fixed.zip`
> (la build originale resta `releases/OpenHackintosh-2.0.1-Beta-1.zip`).

### Corretto — componente di selezione/input del menu (root cause)

Il menu principale leggeva **un solo carattere** e lo convertiva subito in una
scelta (`int(char) - 1`). Un modello a cifra singola, quindi:

- **numeri multi-cifra impossibili**: digitando `1` poi `0` veniva selezionata
  l'opzione `1`, e la voce `[10] Exit` era irraggiungibile da tastiera;
- **frecce non riconosciute in application cursor mode**: erano gestite solo le
  sequenze `ESC [ A` / `ESC [ B`, non `ESC O A` / `ESC O B` — quelle inviate dal
  Terminale di macOS, da `tmux` e da `screen`;
- **ESC bloccava il programma**: dopo `\x1b` veniva eseguita una
  `sys.stdin.read(2)` bloccante, senza timeout;
- **Ctrl+C non funzionava**: `tty.setraw` disabilita ISIG (e OPOST);
- **menu ristampato a ogni tasto** invece di essere aggiornato in place;
- **input non valido ignorato in silenzio**, senza messaggio di errore;
- fallback non-TTY che accettava solo cifre singole e poteva lasciare l'indice
  evidenziato fuori range.

### Aggiunto

- `src/cli/selector.py`: componente di selezione **generico e riusabile**
  - buffer numerico multi-cifra con disambiguazione (cifra successiva, Enter o
    timeout): valido per 10, 12, 100+ opzioni senza modifiche;
  - decoder tastiera completo: `ESC [` (CSI) e `ESC O` (SS3), frecce,
    Home/End/PageUp/PageDown, Tab/Shift+Tab, Backspace/Canc, Enter del
    tastierino, Ctrl+C, Ctrl+D;
  - ESC isolato riconosciuto tramite timeout sulla sequenza;
  - modalità **cbreak** al posto di *raw*: Ctrl+C e l'output restano corretti;
  - lettura via `os.read()` su file descriptor con decoder UTF-8 incrementale
    (niente buffering di `sys.stdin`);
  - ridisegno **in place** del menu con sequenze ANSI, evidenziazione della voce
    attiva e anteprima del numero digitato;
  - messaggi espliciti per l'input non valido, con lo stato del menu preservato;
  - fallback line-based per stdin non interattivo (pipe/CI) con supporto
    multi-cifra, match per etichetta, `q`/`quit`/`exit` e protezione contro i
    loop infiniti.
- `tests/test_selector.py`: 129 test — decodifica tasti, macchina a stati,
  numeri multi-cifra (fino a 123 opzioni), frecce, Enter, ESC, Ctrl+C, input non
  valido, fallback non-TTY, rendering ed **end-to-end su pseudo-terminale reale**.
- `tools/build_release.py`: build riproducibile dello ZIP di distribuzione.
- `docs/HOTFIX-2.0.1-Beta-1-SELECTOR.md`: nota tecnica dell'hotfix.

### Modificato

- `src/cli/interactive.py`: ora è un adattatore sottile sopra `cli.selector`.
  `run_menu()` mantiene la stessa firma e restituisce la voce di uscita quando
  la selezione viene annullata.
- `src/cli/main.py`: voci di menu e mappatura azione→comando estratte in
  `MENU_ITEMS` / `MENU_COMMANDS` (testabili). **La logica delle singole azioni
  non è stata toccata.**

### Invariato

- Versione (`2.0.1 Beta 1`), launcher (`OpenHackintosh.command`,
  `FujitsuEFI.command`, `openhackintosh`, `openhackintosh.sh`), `src/efi/`,
  `src/efi_builder/`, database, detection e compatibilità.

## 2.0.1 Beta 1 - 2026-08-31 - CHECKPOINT DI DISTRIBUZIONE (PRERELEASE)

Questa è una **build di distribuzione/checkpoint** dello stato attuale, non una
nuova fase architetturale. Include:

- **CLI-first workflow**: il tool si usa da terminale, niente GUI/web.
- **Hardware detection/diagnosis**: detection DMI, CPU, GPU, audio, Ethernet, Wi-Fi, USB, storage, ACPI + report `diagnose`.
- **Hardware identification + database matching**: `EXACT_MATCH` / `CLOSE_MATCH` / `PARTIAL_MATCH` / `NO_MATCH`, basato su `src/database/`.
- **Compatibility analysis**: motore deterministico basato su DB/regole/HW-ID, mai su invenzioni AI.
- **EFI generator hardening**: binari reali, validazione Mach-O/PE/COFF/AML, config↔file consistency, zero-byte/placeholder detection, SHA-256, cache, final EFI audit, clean failure.
- **No fake binaries**: se un componente obbligatorio non è ottenibile/verificato, la generazione **fallisce**.
- **Migliorata gestione errori** e output JSON strutturato.

> ⚠️ BETA: il supporto è sperimentale. Nessun profilo viene dichiarato VERIFIED
> senza test fisico sul hardware. Il profilo Q556/2 è marcato VERIFIED dal
> creatore del progetto; Q957 è DOCUMENTED.

## [Unreleased] - 2026-08-30 - v2.0.2 in preparazione (NON PUBBLICATA)

### Rimosso GUI e Web Dashboard: solo terminale

- Rimosso `src/gui/` (GUI customtkinter/tkinter)
- Rimosso `app.py`, `run_web.py`, `templates/`, `static/` (Web Dashboard Flask)
- `main.py` ora è un wrapper che gira direttamente la CLI
- `src/cli.py`: rimossa opzione `--gui`, epilog aggiornato
- `FujitsuEFI.command`: avvio diretto da terminale, niente più tentativo GUI
- `requirements.txt`: rimossi `flask`, `customtkinter`, `pillow`, `packaging`; resta `requests`
- README, CONTRIBUTING, `.github/DESCRIPTION.md` aggiornati: il progetto è CLI-only

### EFI Generator Hardening (2.0.2)

- **NO FAKE BINARIES**: nessun placeholder/fake se un componente obbligatorio non è ottenibile/verificato.
- **Binary validation** (`src/efi/integrity.py`): Mach-O per kext, PE/COFF per driver/OpenCore/BOOTx64, firma AML per SSDT.
- **Hash / Integrity**: SHA-256, versione/source, download time per ogni componente.
- **Download cache** (`~/.cache/openhackintosh`): riusa zip solo se integro; invalida e ri-scarica se corrotti.
- **Config.plist consistency**: cross-reference ACPI/Kext/Driver config <-> file realmente presenti.
- **Zero-byte / placeholder scan** ricorsiva globale.
- **Component Selection minimale**: di default SOLO required. Opzionali espliciti (`--wifi`, `--bluetooth`, `--include-nvme`, `--include-restrict-events`, `--include-optional-drivers`).
- **SSDT da profilo**: Q556/2/Q957 usano `SSDT-PLUG-DRTNIA.aml` e `SSDT-EC-USBX-DESKTOP.aml`; niente AWAC/RHUB automatici.
- **DeviceProperties dal profilo** (no valori inventati).
- **Release vs Dev**: release boot-args pulito; `--dev` abilita debug.
- **Final EFI Audit** (`src/efi/audit.py`) + **generation/failure report** (`VALID` / `FAILED`).
- Interfaccia `generate --json` ora produce JSON pulito (log nascosti in json mode).
- Test di hardening (37 totali) per download failure, fake/invalid binaries, 0-byte, missing kext/driver/ACPI, config mismatch, exit code, Q556/2.

### Hardware Detection / Identification / Diagnosis (2.0.2)

- `DetectedValue` ora espone `value` / `status` / `source`: `DETECTED`, `INFERRED`, `DATABASE_MATCH`, `NOT_DETECTED`, `UNKNOWN`, `NOT_AVAILABLE_ON_PLATFORM`. Se non rilevato: `value: null`.
- Detection arricchita: CPU vendor/architettura/generazione/cores/threads/features; GPU vendor/model/ids/PCI/type/VRAM best-effort; Audio, Ethernet, Wi-Fi con vendor/model/ids/PCI; Bluetooth best-effort (USB/PCI); USB controllers + devices; Storage SATA/NVMe/drives; ACPI tables + DSDT; boot mode UEFI/Legacy.
- **HardwareSnapshot** (`src/hardware/snapshot.py`): rileva una sola volta e condivide detection ↔ matching ↔ compatibility.
- Matcher: `match_type` = `EXACT_MATCH` / `CLOSE_MATCH` / `PARTIAL_MATCH` / `NO_MATCH`.
- Compatibility: `ComponentAssessment.evidence` (Detected / Hardware ID match / Database profile / Documented / Tested) e `match_type` nel JSON.
- `openhackintosh diagnose`: report completo (SYSTEM, CPU, GPU, Audio, Ethernet, Wi-Fi, Storage, DATABASE, DIAGNOSIS, macOS Compatibility, Overall, NOTE). `diagnose --json` produce solo JSON.
- Error handling: la diagnosi continua se una singola sezione di rilevamento fallisce (`detection_errors` tracciato).
- NON toccato il generatore EFI in questa fase.

### Fondazione intelligente (2.0.2)

- **Hardware Detection** (`src/hardware/detection.py`): rileva DMI, CPU, GPU/PCI, audio, Ethernet, WiFi, USB, storage, ACPI; MAI inventa, altrimenti "Unknown / Not detected".
- **Hardware Identification** (`src/hardware/identification.py`): identità confrontabile.
- **Hardware Database JSON** (`src/database/profiles/`): profili `fujitsu_q556_2` e `fujitsu_q957` con stato VERIFIED / DOCUMENTED / UNKNOWN.
- **Database Loader + Matcher** (`src/database/`): caricamento autonomo e matching deterministico per modello/board/HW ID.
- **Compatibility Engine** (`src/compatibility/`): confronto hardware vs profilo con stati compatible/partial/unsupported/unknown. Non usa AI per decidere.
- **AI Layer** (`src/ai/`): solo spiegazione sopra il risultato del motore.
- **EFI Generator hardware-aware** (`src/efi/` + `src/efi_builder/builder.py`): include solo componenti necessari; il download di un componente obbligatorio che fallisce ABORTA, non crea placeholder.
- **EFI Validator avanzato** (`src/efi_builder/validator.py`): rileva 0-byte, placeholder, missing, componenti configurati ma assenti, config/file inconsistency.
- **CLI commands**: `detect`, `info`, `diagnose`, `compatibility`, `generate`, `validate`, `doctor`, `database`, `bios`, `ask`.
- **Output JSON** su tutti i comandi principali; `--dev` per verbose/debug.
- **Guida BIOS per profilo**: `openhackintosh bios --profile fujitsu_q556_2`, solo impostazioni pertinenti, con "requires hardware verification".
- **Tests pytest** (24): detection, database, matching, compatibility, validator 0-byte/placeholder/missing, CLI JSON, reference Q556/2.

## [2.1.0] - 2026-08-29 - OpenHackintosh 🍎

### Perché ho cambiato nome?

Perché alla fine non è solo per Q556/2. Il codice per generare EFI è uguale per tanti PC, ho solo fatto il profilo Q556/2 come principale perché è quello che ho io. Ma se uno ha Q957 o altro Skylake, funziona uguale. Quindi ho detto: chiamiamolo OpenHackintosh, più generico, più figo.

- README riscritto da zero, più umano
- Titolo da "Fujitsu Esprimo Q556/2 Auxiliary Tool" a "OpenHackintosh"
- Descrizione: da tecnica e noiosa a "EFI vere, non finte"
- Preparato per rename repo su GitHub
- Release v2.1.0 con nuovo nome

### Come rinominare repo su GitHub (per me, che me lo dimentico sempre)

1. Vai su Settings del repo
2. General -> Repository name
3. Cambia in OpenHackintosh
4. Rename

GitHub fa redirect automatico, quindi vecchi link continuano a funzionare.

## [2.0.0] - 2026-08-29 - Basta file finti 💥

### La storia

Avevo una prima versione del tool. Bellissima fuori, vuota dentro. Letteralmente file da 0 byte. 3 giorni a bestemmiare davanti a logo Fujitsu che si riavviava.

Ho riscritto tutto da zero.

### Cosa ho fixato

**Prima:**
- BOOTx64.efi 0 byte (finto)
- Lilu.kext senza binario (solo Info.plist vuoto)
- config.plist a caso
- Non bootava mai

**Ora:**
- BOOTx64.efi vero 50KB+ da OpenCorePkg ufficiale
- Kext veri con binari 200-300KB da GitHub ufficiale
- SSDT veri da Dortania
- config.plist fatto seguendo Dortania Skylake
- SMBIOS validi generati
- ZIP pronto per USB che boota davvero

### Novità

- `downloader.py` - Scarica file veri da GitHub API, con progress bar e fallback se mancano certificati SSL
- `config_generator.py` - Genera config.plist corretto per Skylake, con patch HD 530, DVMT fix, alcid=11
- `smbios.py` - Genera seriali validi (12 chars, 17 chars MLB, UUID, ROM) - poi rigeneri con GenSMBIOS per uso tuo
- `validator.py` - Controlla se file sono finti/vuoti (se <100 byte, è finto)
- Profili hardware: Q556/2 (D3403-U, H110, Realtek RTL8111GN, ALC671) e Q957 (Intel LAN)
- Supporto macOS: Monterey, Ventura (consigliato, lo uso io), Sonoma, Sequoia sperimentale
- Auto-swap kext LAN: Realtek per Q556/2, IntelMausi per Q957
- GUI moderna con customtkinter: dark mode, card layout, SF Pro font, progress bar, log live, hardware info, SMBIOS preview - prima era brutta forte
- CLI completo con argparse, help umano
- Web Dashboard Flask: gradient, blur, glassmorphism, responsive, log live - l'ho fatta perché in sandbox non potevo far girare GUI macOS
- Validazione EFI integrata
- Icona 3D professionale (mini PC + Apple glow)
- Launcher macOS FujitsuEFI.command (doppio click)
- README con BIOS setup, troubleshooting, tabella kext - scritto col sangue
- docs/FAKE_VS_REAL.md - spiego perché prima non andava, con esempi file finti vs veri
- docs/BIOS_GUIDE.md - guida BIOS con DVMT 64MB ovunque perché è fondamentale
- LICENSE MIT, CONTRIBUTING, .gitignore

### Design

Prima: UI base con tkinter standard, colori default, layout semplice, nessuna progress bar, log testuale base.

Ora:
- GUI: customtkinter, dark theme, blue accent, card layout, SF Pro font, progress bar, log colorato, badge, hardware info, SMBIOS preview
- Web: gradient, blur, glassmorphism, monospace log, status badge, responsive
- Icona: 3D render mini PC + Apple glow, professionale
- README: badges, tabelle, emoji, storia personale, più umano

### Tecnico

- Struttura progetto professionale: src/efi_builder/, src/gui/, assets/, tools/, templates/
- Type hints, dataclasses, error handling
- GitHub API per latest releases
- Zip extraction con ricerca ricorsiva kext
- Plist generation con xml
- Threading per build non bloccante
- Progress callback

### Test

- Testato offline build con dummy files - genera struttura valida e ZIP
- Testato import - tutti i moduli si importano
- Testato download GitHub API - funziona su macOS con certificati, in sandbox Linux mancano certificati ma ho messo fallback

## [1.0.0] - 2026-08-28 - Quello finto

- Generazione struttura EFI
- File vuoti/finti (problema)
- Design base
- Prima versione non funzionante
- Non bootava
- 3 giorni di bestemmie

---

Morale: non fidarti dei tool che generano file senza scaricarli da fonti ufficiali. Se EFI è 100KB totale, è finta. Una vera è 15-20MB.
