"""
Web Dashboard for Fujitsu Esprimo Q556/2 EFI Creator
For preview in sandbox - modern macOS-like design
"""
import sys
from pathlib import Path
import json
import threading
import time

sys.path.insert(0, str(Path(__file__).parent / "src"))

from flask import Flask, render_template, request, jsonify, send_file
from efi_builder.hardware import PROFILES, MACOS_VERSIONS, get_kexts_for_profile
from efi_builder.builder import EFIBuilder
from efi_builder.smbios import generate_smbios
from efi_builder.validator import validate_efi

app = Flask(__name__, template_folder="templates", static_folder="static")

# Ensure dirs
Path("templates").mkdir(exist_ok=True)
Path("static").mkdir(exist_ok=True)

# Global build status
build_status = {
    "running": False,
    "logs": [],
    "result": None,
    "progress": 0
}

@app.route("/")
def index():
    return render_template("index.html", profiles=PROFILES, macos_versions=MACOS_VERSIONS)

@app.route("/api/profiles")
def api_profiles():
    data = {}
    for name, p in PROFILES.items():
        data[name] = {
            "name": p.name,
            "board": p.board,
            "chipset": p.chipset,
            "cpu": p.cpu_generations,
            "igpu": p.igpu,
            "lan": p.lan_chip,
            "lan_kext": p.lan_kext,
            "audio": p.audio_codec,
            "audio_layouts": p.audio_layout_ids,
            "smbios": p.smbios_recommended,
            "notes": p.notes
        }
    return jsonify(data)

@app.route("/api/macos")
def api_macos():
    return jsonify(MACOS_VERSIONS)

@app.route("/api/generate_smbios")
def api_gen_smbios():
    model = request.args.get("model", "iMac18,1")
    smbios = generate_smbios(model)
    return jsonify(smbios)

@app.route("/api/build", methods=["POST"])
def api_build():
    global build_status
    if build_status["running"]:
        return jsonify({"error": "Build already running"}), 400
    
    data = request.json
    profile = data.get("profile", "Q556/2")
    macos = data.get("macos", "Ventura 13.x")
    smbios_model = data.get("smbios", "iMac18,1")
    audio_layout = int(data.get("audio_layout", 11))
    include_wifi = data.get("wifi", False)
    include_bt = data.get("bluetooth", False)
    output_name = data.get("output", "EFI_Q5562")
    
    output_dir = Path("/tmp") / output_name
    if output_dir.exists():
        import shutil
        shutil.rmtree(output_dir)
    
    build_status = {
        "running": True,
        "logs": [f"Starting build for {profile} / {macos} / {smbios_model}"],
        "result": None,
        "progress": 0.1,
        "output_dir": str(output_dir)
    }
    
    def build_thread():
        global build_status
        try:
            def progress_cb(name, current, total):
                if total > 0:
                    build_status["progress"] = 0.1 + 0.8 * (current / total)
            
            def log_cb(event, msg=""):
                if event == "log":
                    build_status["logs"].append(msg)
                    # Keep only last 100
                    if len(build_status["logs"]) > 100:
                        build_status["logs"] = build_status["logs"][-100:]
            
            builder = EFIBuilder(output_dir, progress_callback=progress_cb)
            builder.progress_callback = log_cb
            
            result = builder.build(
                profile_name=profile,
                smbios_model=smbios_model,
                audio_layout=audio_layout,
                macos_version=macos,
                include_wifi=include_wifi,
                include_bluetooth=include_bt,
                generate_zip=True
            )
            
            build_status["result"] = result
            build_status["progress"] = 1.0
            build_status["logs"].append("✓ Build complete!")
            
            # Validate
            if result["success"]:
                validation = validate_efi(Path(result["efi_path"]))
                build_status["validation"] = validation
            
        except Exception as e:
            import traceback
            build_status["logs"].append(f"✗ Error: {e}")
            build_status["logs"].append(traceback.format_exc())
            build_status["result"] = {"success": False, "error": str(e)}
        finally:
            build_status["running"] = False
    
    threading.Thread(target=build_thread, daemon=True).start()
    
    return jsonify({"status": "started", "output_dir": str(output_dir)})

@app.route("/api/status")
def api_status():
    return jsonify(build_status)

@app.route("/api/logs")
def api_logs():
    return jsonify({"logs": build_status["logs"], "running": build_status["running"], "progress": build_status["progress"]})

if __name__ == "__main__":
    # Create template if not exists
    template_path = Path("templates/index.html")
    if not template_path.exists():
        template_path.write_text("""
<!DOCTYPE html>
<html lang="it">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Fujitsu Q556/2 EFI Creator</title>
<style>
:root {
  --bg: #0a0a0a;
  --card: #1a1a1a;
  --border: #2a2a2a;
  --text: #e5e5e5;
  --text-dim: #888;
  --accent: #007AFF;
  --accent-hover: #0056b3;
  --success: #30d158;
  --warning: #ffd60a;
  --error: #ff453a;
}
* { margin:0; padding:0; box-sizing:border-box; }
body { 
  font-family: -apple-system, BlinkMacSystemFont, 'SF Pro Display', sans-serif;
  background: var(--bg);
  color: var(--text);
  min-height: 100vh;
}
.header {
  padding: 40px;
  border-bottom: 1px solid var(--border);
  background: linear-gradient(180deg, #1a1a1a 0%, #0a0a0a 100%);
}
.header h1 {
  font-size: 32px;
  font-weight: 700;
  letter-spacing: -0.5px;
  margin-bottom: 8px;
}
.header p { color: var(--text-dim); font-size: 16px; }
.header .badge {
  display: inline-block;
  background: var(--success);
  color: black;
  padding: 4px 12px;
  border-radius: 20px;
  font-size: 12px;
  font-weight: 600;
  margin-top: 12px;
}
.container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 30px;
  display: grid;
  grid-template-columns: 380px 1fr;
  gap: 30px;
}
.card {
  background: var(--card);
  border: 1px solid var(--border);
  border-radius: 16px;
  padding: 24px;
  backdrop-filter: blur(20px);
}
.card h2 {
  font-size: 18px;
  font-weight: 600;
  margin-bottom: 20px;
  display: flex;
  align-items: center;
  gap: 10px;
}
.form-group { margin-bottom: 20px; }
.form-group label {
  display: block;
  font-size: 13px;
  font-weight: 500;
  color: var(--text-dim);
  margin-bottom: 8px;
  text-transform: uppercase;
  letter-spacing: 0.5px;
}
.form-group select, .form-group input {
  width: 100%;
  background: #2a2a2a;
  border: 1px solid #3a3a3a;
  color: var(--text);
  padding: 12px 16px;
  border-radius: 10px;
  font-size: 14px;
  outline: none;
  transition: all 0.2s;
}
.form-group select:focus, .form-group input:focus {
  border-color: var(--accent);
  background: #333;
}
.checkbox {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 12px;
  background: #222;
  border-radius: 10px;
  margin-bottom: 10px;
  cursor: pointer;
  transition: all 0.2s;
}
.checkbox:hover { background: #2a2a2a; }
.checkbox input { width: 18px; height: 18px; }
.checkbox label { margin:0; text-transform:none; font-size:14px; color: var(--text); cursor:pointer; }
.btn {
  width: 100%;
  padding: 16px;
  border: none;
  border-radius: 12px;
  font-size: 16px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.2s;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
}
.btn-primary {
  background: var(--accent);
  color: white;
}
.btn-primary:hover { background: var(--accent-hover); transform: translateY(-1px); }
.btn-primary:disabled { opacity:0.5; cursor:not-allowed; transform:none; }
.btn-secondary {
  background: #2a2a2a;
  color: var(--text);
  margin-top: 10px;
}
.progress {
  width: 100%;
  height: 6px;
  background: #2a2a2a;
  border-radius: 3px;
  overflow: hidden;
  margin: 20px 0;
}
.progress-bar {
  height: 100%;
  background: linear-gradient(90deg, var(--accent), var(--success));
  width: 0%;
  transition: width 0.3s;
}
.log {
  background: #0a0a0a;
  border: 1px solid var(--border);
  border-radius: 10px;
  padding: 16px;
  font-family: 'SF Mono', Monaco, monospace;
  font-size: 12px;
  height: 400px;
  overflow-y: auto;
  white-space: pre-wrap;
  line-height: 1.5;
}
.log .success { color: var(--success); }
.log .error { color: var(--error); }
.log .info { color: var(--text-dim); }
.hardware-info {
  background: #222;
  border-radius: 10px;
  padding: 16px;
  margin-top: 16px;
  font-size: 12px;
  line-height: 1.6;
}
.hardware-info strong { color: var(--text); }
.smbios-preview {
  background: linear-gradient(135deg, #1a1a1a, #2a2a2a);
  border: 1px solid #333;
  border-radius: 12px;
  padding: 16px;
  margin-top: 20px;
  font-family: monospace;
  font-size: 11px;
}
.status-badge {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  padding: 6px 12px;
  border-radius: 20px;
  font-size: 12px;
  font-weight: 600;
}
.status-ready { background: #2a2a2a; color: var(--text-dim); }
.status-running { background: #003366; color: #66b3ff; }
.status-success { background: #003300; color: var(--success); }
.status-error { background: #330000; color: var(--error); }
@media (max-width: 900px) {
  .container { grid-template-columns: 1fr; }
}
</style>
</head>
<body>
<div class="header">
  <h1>Fujitsu Esprimo Q556/2</h1>
  <p>Hackintosh EFI Creator — Tool ausiliario che genera EFI REALI, non finte</p>
  <div class="badge">✓ REAL FILES • NO FAKE • OpenCore Ufficiale</div>
</div>

<div class="container">
  <div>
    <div class="card">
      <h2>⚙️ Configurazione</h2>
      
      <div class="form-group">
        <label>Modello Hardware</label>
        <select id="profile">
          <option value="Q556/2" selected>Q556/2 (Realtek LAN)</option>
          <option value="Q957">Q957 (Intel LAN)</option>
        </select>
        <div id="profile-info" class="hardware-info"></div>
      </div>

      <div class="form-group">
        <label>Versione macOS Target</label>
        <select id="macos">
          <option value="Ventura 13.x" selected>Ventura 13.x (Consigliato)</option>
          <option value="Monterey 12.x">Monterey 12.x (Stabile)</option>
          <option value="Sonoma 14.x">Sonoma 14.x (Richiede iMacPro1,1)</option>
          <option value="Sequoia 15.x">Sequoia 15.x (Sperimentale)</option>
        </select>
      </div>

      <div class="form-group">
        <label>SMBIOS Model</label>
        <select id="smbios">
          <option value="iMac18,1" selected>iMac18,1 (Skylake, consigliato)</option>
          <option value="iMac17,1">iMac17,1 (Skylake legacy)</option>
          <option value="iMac19,1">iMac19,1 (Coffee Lake)</option>
          <option value="Macmini8,1">Macmini8,1 (Compatto)</option>
          <option value="iMacPro1,1">iMacPro1,1 (Per Sonoma/Sequoia)</option>
        </select>
      </div>

      <div class="form-group">
        <label>Audio Layout ID (ALC671)</label>
        <select id="audio">
          <option value="11" selected>11 (Consigliato)</option>
          <option value="13">13</option>
          <option value="15">15</option>
          <option value="21">21</option>
          <option value="27">27</option>
          <option value="28">28</option>
        </select>
      </div>

      <div class="form-group">
        <label>Opzioni Aggiuntive</label>
        <div class="checkbox">
          <input type="checkbox" id="wifi">
          <label for="wifi">Include Intel WiFi (AirportItlwm)</label>
        </div>
        <div class="checkbox">
          <input type="checkbox" id="bt">
          <label for="bt">Include Intel Bluetooth</label>
        </div>
      </div>

      <div class="form-group">
        <label>Nome Output</label>
        <input type="text" id="output" value="EFI_Q5562" placeholder="EFI_Q5562">
      </div>

      <button class="btn btn-primary" id="build-btn" onclick="startBuild()">
        <span>🚀</span> Genera EFI Reale
      </button>
      <button class="btn btn-secondary" onclick="generateSMBIOS()">🎲 Genera SMBIOS Preview</button>
    </div>

    <div class="card" style="margin-top:20px;">
      <h2>📋 BIOS Setup Richiesto</h2>
      <div style="font-size:13px; line-height:1.6; color:var(--text-dim);">
        <strong style="color:var(--error);">Disabilita:</strong><br>
        Fast Boot, Secure Boot, Serial Port, VT-d, CSM, SGX<br><br>
        <strong style="color:var(--success);">Abilita:</strong><br>
        VT-x, Above 4G, EHCI/XHCI Hand-off, OS UEFI, DVMT 64MB (CRITICO)
      </div>
    </div>
  </div>

  <div>
    <div class="card">
      <h2>📊 Stato & Log <span id="status-badge" class="status-badge status-ready">● Pronto</span></h2>
      
      <div class="progress"><div class="progress-bar" id="progress"></div></div>
      
      <div class="log" id="log">Benvenuto nel Fujitsu Q556/2 EFI Creator!

Questo tool RISOLVE il problema dei file finti:
❌ Prima: struttura EFI ma file vuoti/finti
✅ Ora: download REALI da GitHub ufficiale

Cosa fa:
• Scarica OpenCorePkg ufficiale da Acidanthera
• Scarica kext REALI (Lilu, VirtualSMC, WhateverGreen, AppleALC, RealtekRTL8111)
• Genera config.plist corretto per Skylake Desktop (Dortania guide)
• Crea SSDT necessari (PLUG, EC-USBX, AWAC, PMC)
• Genera SMBIOS validi
• Valida EFI e crea ZIP pronto

Seleziona le opzioni e clicca Genera.
</div>

      <div id="smbios-preview" class="smbios-preview" style="display:none;"></div>
      
      <div id="result" style="margin-top:20px; display:none;"></div>
    </div>
  </div>
</div>

<script>
let profiles = {};
fetch('/api/profiles').then(r=>r.json()).then(data=>{
  profiles = data;
  updateProfileInfo();
});

function updateProfileInfo(){
  const p = document.getElementById('profile').value;
  const info = profiles[p];
  if(!info) return;
  document.getElementById('profile-info').innerHTML = `
    <strong>Board:</strong> ${info.board}<br>
    <strong>Chipset:</strong> ${info.chipset}<br>
    <strong>LAN:</strong> ${info.lan} (${info.lan_kext})<br>
    <strong>Audio:</strong> ${info.audio}<br>
    <strong>iGPU:</strong> ${info.igpu}
  `;
}
document.getElementById('profile').addEventListener('change', updateProfileInfo);

function generateSMBIOS(){
  const model = document.getElementById('smbios').value;
  fetch(`/api/generate_smbios?model=${model}`).then(r=>r.json()).then(data=>{
    const preview = document.getElementById('smbios-preview');
    preview.style.display = 'block';
    preview.innerHTML = `<strong>SMBIOS Preview (${data.ProductName}):</strong><br>
    Serial: ${data.SerialNumber}<br>
    MLB: ${data.MLB}<br>
    UUID: ${data.SystemUUID}<br>
    ROM: ${data.ROM}`;
  });
}

let pollInterval = null;
function startBuild(){
  const btn = document.getElementById('build-btn');
  btn.disabled = true;
  btn.innerHTML = '⏳ Generazione in corso...';
  document.getElementById('status-badge').className = 'status-badge status-running';
  document.getElementById('status-badge').innerHTML = '● In corso';
  document.getElementById('log').textContent = '';
  document.getElementById('progress').style.width = '10%';
  
  const payload = {
    profile: document.getElementById('profile').value,
    macos: document.getElementById('macos').value,
    smbios: document.getElementById('smbios').value,
    audio_layout: document.getElementById('audio').value,
    wifi: document.getElementById('wifi').checked,
    bluetooth: document.getElementById('bt').checked,
    output: document.getElementById('output').value
  };
  
  fetch('/api/build', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(payload)})
  .then(r=>r.json())
  .then(data=>{
    if(data.error){
      alert(data.error);
      btn.disabled = false;
      return;
    }
    pollInterval = setInterval(pollLogs, 1000);
  });
}

function pollLogs(){
  fetch('/api/status').then(r=>r.json()).then(data=>{
    document.getElementById('log').textContent = data.logs.join('\\n');
    document.getElementById('log').scrollTop = document.getElementById('log').scrollHeight;
    document.getElementById('progress').style.width = (data.progress*100)+'%';
    
    if(!data.running){
      clearInterval(pollInterval);
      const btn = document.getElementById('build-btn');
      btn.disabled = false;
      btn.innerHTML = '🚀 Genera EFI Reale';
      
      if(data.result && data.result.success){
        document.getElementById('status-badge').className = 'status-badge status-success';
        document.getElementById('status-badge').innerHTML = '● Completato';
        
        const smbios = data.result.smbios;
        document.getElementById('smbios-preview').style.display = 'block';
        document.getElementById('smbios-preview').innerHTML = `
          <strong style="color:#30d158;">✓ EFI Generata!</strong><br><br>
          <strong>Model:</strong> ${smbios.ProductName}<br>
          <strong>Serial:</strong> ${smbios.SerialNumber}<br>
          <strong>MLB:</strong> ${smbios.MLB}<br>
          <strong>UUID:</strong> ${smbios.SystemUUID}<br>
          <strong>ROM:</strong> ${smbios.ROM}<br><br>
          <strong>Path:</strong> ${data.result.efi_path}<br>
          <strong>ZIP:</strong> ${data.result.zip_path}
        `;
        
        const resDiv = document.getElementById('result');
        resDiv.style.display = 'block';
        let kextHtml = '<div style="margin-top:10px;">';
        for(const [k,v] of Object.entries(data.result.kext_results)){
          kextHtml += `<span style="color:${v?'#30d158':'#ff453a'}">${v?'✓':'✗'} ${k}</span> `;
        }
        kextHtml += '</div>';
        resDiv.innerHTML = kextHtml;
        
        if(data.validation){
          resDiv.innerHTML += `<div style="margin-top:10px; padding:10px; background:#222; border-radius:8px; font-size:12px;">
            <strong>Validazione:</strong> ${data.validation.valid?'✓ Valida':'✗ Problemi'}<br>
            Kexts: ${data.validation.checks['kexts found']||0}, ACPI: ${data.validation.checks['acpi found']||0}
          </div>`;
        }
      } else {
        document.getElementById('status-badge').className = 'status-badge status-error';
        document.getElementById('status-badge').innerHTML = '● Errore';
      }
    }
  });
}
</script>
</body>
</html>
        """)

    app.run(host="0.0.0.0", port=5000, debug=False)
