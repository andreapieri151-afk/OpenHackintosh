# EFI Q556/2 v2.1.0 SAMPLE - Specifica per Fujitsu Esprimo Q556/2

Questa è una EFI di ESEMPIO generata con le fix v2.1.0, così puoi analizzarla.

## Cosa c'è dentro (fix v2.1.0)

### ACPI (OC/ACPI) - FIX 0-byte bug
- SSDT-PLUG-DRTNIA.aml (REQUIRED, 800+ byte REALI) - CPU power management per Skylake
- SSDT-EC-USBX-DESKTOP.aml (REQUIRED, 800+ byte REALI) - EC fix
- SSDT-PMC.aml (OPTIONAL, solo se NVRAM rotta)
- SSDT-AWAC.aml (0 byte creato apposta per test filtro) -> FILTRATO in config.plist

Per Q556/2 H110 Skylake, Dortania dice: solo PLUG-DRTNIA + EC-USBX-DESKTOP sono REQUIRED.
AWAC è solo per Coffee Lake+ (300 series), Q556/2 NON ha AWAC. RHUB solo per Comet Lake+.

### Drivers (OC/Drivers) - Minimal Q556/2
- HfsPlus.efi (Enabled=True) - REQUIRED per leggere HFS+
- OpenRuntime.efi (Enabled=True, LoadEarly=True) - REQUIRED sempre
- OpenCanopy.efi (Enabled=False) - OPTIONAL GUI, disabilitato per minimal
- ResetNvramEntry.efi (Enabled=False) - OPTIONAL debug

In EFI 2.0.0 erano tutti Enabled indiscriminatamente (generica). Ora minimal specifica.

### Kexts (OC/Kexts) - Minimal
- Lilu.kext, VirtualSMC.kext, WhateverGreen.kext, AppleALC.kext, RealtekRTL8111.kext
Solo 5 essenziali per Q556/2.

### config.plist - Specifico Q556/2
- ACPI: 2 SSDT enabled (PLUG-DRTNIA + EC-USBX), AWAC 0-byte filtrato
- UEFI Drivers: 3 configurati, solo 2 enabled
- Boot-args RELEASE: alcid=11 (solo, pulito)
- Boot-args DEV (config_DEV.plist): -v keepsyms=1 debug=0x100 alcid=11
- DeviceProperties: DP con0 00040000, DVI-D con1 00080000 HDMI type, con2 disabled (2 porte fisiche)
- framebuffer patches per DVMT 32MB (00003001 + 00009000)
- Misc Debug: RELEASE Target=0 AppleDebug=False, DEV Target=67
- SMBIOS: iMac18,1 C02J607DME6V (generato individuale, no preset)

## Verifica

1. Apri OC/config.plist con ProperTree
2. ACPI -> Add: solo 2 SSDT enabled (PLUG-DRTNIA, EC-USBX-DESKTOP), AWAC filtrato
3. UEFI -> Drivers: 3 entries, solo HfsPlus e OpenRuntime Enabled=True
4. NVRAM -> boot-args: alcid=11 (RELEASE) vs -v keepsyms... alcid=11 (DEV)
5. DeviceProperties -> PciRoot(0x0)/Pci(0x2,0x0): con0 DP, con1 HDMI, con2 disabled
6. PlatformInfo -> Generic: seriali generati individuali

## Differenze vs EFI 2.0.0

EFI 2.0.0:
- SSDT-PLUG.aml, EC-USBX.aml, AWAC.aml, PMC.aml nomi sbagliati, 0 byte
- Drivers tutti Enabled
- Kexts con opzionali di default
- Boot-args sempre con -v debug
- DeviceProperties generica 3 connettori

EFI 2.1.0 (questa):
- SSDT-PLUG-DRTNIA.aml, EC-USBX-DESKTOP.aml nomi corretti Dortania, >0 byte, AWAC filtrato
- Drivers minimal 2 Enabled
- Kexts minimal 5
- Boot-args RELEASE pulito
- DeviceProperties specifica 2 porte DP+DVI-D

Generata: 2026-08-30
Tool: OpenHackintosh v2.1.0 audit fix
SMBIOS: {'ProductName': 'iMac18,1', 'SerialNumber': 'C02J607DME6V', 'MLB': 'C02J607DME6VMUMSR', 'SystemUUID': '27F95A0A-FB07-4098-A44D-4379ED4E9331', 'ROM': '02DAD0D06D85', 'SystemProductName': 'iMac18,1'}
